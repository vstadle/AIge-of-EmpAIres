====================================================

 Thanks for downloading my game art asset!

====================================================

 Author		: hernandack
 Page		: https://hernandack.itch.io
 Instagram	: @hernandack
 Twitter 	: @hernandack

====================================================

 - You can use it for commercial or non-commercial
 - Credit for the author is appreciated
 - Permission for use is hereby granted

====================================================